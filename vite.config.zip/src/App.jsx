import Header from './components/Header'
import UploadSection from './components/UploadSection'
import ThreeDViewer from './components/ThreeDViewer'
import MaterialTable from './components/MaterialTable'
import Explanation from './components/Explanation'

const App = () => {
  return (
    <>
      <Header />

      <div id="upload">
        <UploadSection />
      </div>

      <div id="threedmodel">
        <ThreeDViewer />
      </div>

      <div id="materials">
        <MaterialTable />
      </div>

      <div id="explanation">
        <Explanation />
      </div>
    </>
  )
}

export default App