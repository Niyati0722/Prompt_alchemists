import React from 'react'

function ThreeDViewer() {
    return (
        <>
            */ sample code add kiya hu remove kar dena hai, ye sirf placeholder hai, aap apne hisab se content add kar sakte hain. /*
            <h2>3D Viewer</h2>
            <p>This is the 3D viewer section.</p>
        </>
    )
}

export default ThreeDViewer
