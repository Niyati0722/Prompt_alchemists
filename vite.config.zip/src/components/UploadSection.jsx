import React from 'react'

function UploadSection() {
    return (
        <>
            */ sample code add kiya hu remove kar dena hai, ye sirf placeholder hai, aap apne hisab se content add kar sakte hain. /*
            <h2>Upload Section</h2>
            <p>This is the upload section.</p>
        </>
    )
}

export default UploadSection
